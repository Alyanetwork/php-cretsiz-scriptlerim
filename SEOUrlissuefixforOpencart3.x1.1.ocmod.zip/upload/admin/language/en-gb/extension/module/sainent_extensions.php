<?php
// Heading
$_['heading_title']    = '<strong style="color:#0BB3EF">Sainent Extensions<strong>';
$_['text_title']    = 'Sainent Extensions';

?>